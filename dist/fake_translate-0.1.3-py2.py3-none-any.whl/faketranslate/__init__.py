# -*- encoding: utf-8 -*-
"""
@File           : __init__.py.py
@Time           : 2019/12/31 18:51
@Author         : Flack
@Email          : opencoding@hotmail.com
@ide            : PyCharm
@project        : faketranslate
@description    : 描述
"""
VERSION = (0, 1, 3)
__version__ = '.'.join([str(x) for x in VERSION])
