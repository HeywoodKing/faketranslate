# -*- encoding: utf-8 -*-
"""
@File           : metadata.py
@Time           : 2020/1/1
@Author         : flack
@Email          : opencoding@hotmail.com
@ide            : PyCharm
@project        : faketranslate
@description    : 描述
"""